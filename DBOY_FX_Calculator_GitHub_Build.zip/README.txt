DBOY FX CALCULATOR v1.0
Android Studio project (offline WebView app).

BUILD:
1. Extract this ZIP.
2. Open Android Studio > Open > select the DBOY_FX_Calculator folder.
3. Allow Gradle sync. Internet may be needed for the first Gradle/plugin download.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Find the APK from app/build/outputs/apk/debug/app-debug.apk

This ZIP contains the Android Studio source project, not a precompiled APK.
The app calculates tempo-synced delay time, beat-based reverb decay starting point,
and tempo-based pre-delay. Values are starting points; final effect settings depend
on the vocal, arrangement, and listening.

PHONE-ONLY BUILD USING GITHUB ACTIONS:
1. Create a new GitHub repository from your phone (browser or GitHub app).
2. Upload the CONTENTS of this project folder, including the hidden .github folder.
   Make sure .github/workflows/build-apk.yml is uploaded at that exact path.
3. Use repository branch named main.
4. Open the repository's Actions tab and select "Build DBOY FX APK".
5. Tap "Run workflow" if it did not start automatically after upload.
6. When the run finishes successfully, open that run and download the
   "DBOY-FX-Calculator-APK" artifact. Extract the downloaded artifact ZIP;
   inside is app-debug.apk.
7. Open the APK on your Android phone and allow installation from that source
   if Android asks. Only install APKs you built from this project repository.

The first cloud build downloads Gradle and Android SDK components and needs internet.

GITHUB ACTIONS: Upload the extracted project contents to the root of your GitHub repository on branch main. The included .github/workflows/android.yml builds a debug APK on push. Download it from the completed Actions run under Artifacts.
